--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.23
-- Dumped by pg_dump version 10.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP TRIGGER trg_update_stock_on_approval ON public.approval;
DROP TRIGGER trg_insert_id_role ON public.users;
DROP TRIGGER trg_approval_update_stock_qty ON public.karyawan;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.stok DROP CONSTRAINT stok_pkey;
ALTER TABLE ONLY public.role DROP CONSTRAINT role_pkey;
ALTER TABLE ONLY public.pertanggung_jawaban DROP CONSTRAINT pertanggung_jawaban_pkey;
ALTER TABLE ONLY public.pengajuan_pettycash DROP CONSTRAINT pengajuan_pettycash_pkey;
ALTER TABLE ONLY public.pengajuan_barang DROP CONSTRAINT pengajuan_barang_pkey;
ALTER TABLE ONLY public.barang DROP CONSTRAINT barang_pkey;
ALTER TABLE ONLY public.approval DROP CONSTRAINT approval_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.stok ALTER COLUMN id_stok DROP DEFAULT;
ALTER TABLE public.role ALTER COLUMN id_role DROP DEFAULT;
DROP VIEW public.v_users;
DROP VIEW public.v_stock;
DROP VIEW public.v_pengajuan_barang;
DROP VIEW public.v_karyawan;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.stok_id_stok_seq;
DROP TABLE public.stok;
DROP SEQUENCE public.role_id_role_seq;
DROP TABLE public.role;
DROP TABLE public.pertanggung_jawaban;
DROP TABLE public.pengajuan_pettycash;
DROP SEQUENCE public.pengajuan_barang_seq;
DROP TABLE public.pengajuan_barang_detail;
DROP TABLE public.pengajuan_barang;
DROP SEQUENCE public.karyawan_seq;
DROP TABLE public.karyawan;
DROP TABLE public.global_param;
DROP SEQUENCE public.barang_seq;
DROP TABLE public.barang;
DROP SEQUENCE public.approval_seq;
DROP TABLE public.approval;
DROP FUNCTION public.update_user_on_update_karyawan();
DROP FUNCTION public.insert_id_role();
DROP FUNCTION public.f_update_stock_barang();
DROP FUNCTION public.f_gen_id(i_id_name character varying, i_seq character varying);
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: f_gen_id(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.f_gen_id(i_id_name character varying, i_seq character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$ 
declare
/*
 * fungsi untuk membuat id dari pola id yang tersimpan di global_param 
 * return : pola dengan penambahan sequence 
 */
v_return_id VARCHAR;
v_placeholder VARCHAR;
v_code varchar;
v_date varchar;
v_seq varchar;
BEGIN
	SELECT VALUE INTO v_placeholder
	FROM global_param 
	WHERE NAME = i_id_name;

v_code = split_part(v_placeholder, '-', 1);
v_date = replace(split_part(v_placeholder, '-', 2), 'YYYYMM', to_char(current_date, 'YYYYMM'));
v_seq := lpad(to_char(nextval(i_seq), 'FM99999'), length(split_part(v_placeholder, '-', 3)), '0');
v_return_id = v_code || '-' || v_date || '-' || v_seq;

RETURN v_return_id;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			RAISE EXCEPTION 'No data found for %', i_id_name;
		WHEN others then
			return null;
END;
$$;


ALTER FUNCTION public.f_gen_id(i_id_name character varying, i_seq character varying) OWNER TO postgres;

--
-- Name: f_update_stock_barang(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.f_update_stock_barang() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
v_qty integer;
v_id_barang varchar;
begin
	
  select kuantitas, id_barang
  	into v_qty, v_id_barang
  	from pengajuan_barang
  	where id_pengajuan = new.id_pengajuan;
  
  -- For an INSERT operation, add the new quantity to the stock
  IF TG_OP = 'INSERT' then
    UPDATE stok 
    SET stok = stok - v_qty
    WHERE id_barang = v_id_barang;
  -- For an UPDATE operation, calculate the difference and update the stock
  ELSIF TG_OP = 'UPDATE' THEN
   
  select kuantitas, id_barang
  	into v_qty, v_id_barang
  	from pengajuan_barang
  	where id_pengajuan = new.id_pengajuan;
  	
  	if new.status = 'REJECTED' then
		UPDATE stok 
	    SET stok = stok + v_qty
	    WHERE id_barang = v_id_barang;
  	end if;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.f_update_stock_barang() OWNER TO postgres;

--
-- Name: insert_id_role(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_id_role() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- For an INSERT operation, add the new quantity to the stock
  IF TG_OP = 'INSERT' THEN
    UPDATE users u
    SET id_role = (select id_role from karyawan where email = u.email)
    WHERE id = new.id;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.insert_id_role() OWNER TO postgres;

--
-- Name: update_user_on_update_karyawan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_user_on_update_karyawan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- For an INSERT operation, add the new quantity to the stock
  IF TG_OP = 'DELETE' THEN
    delete from users 
    where email = old.email;
  -- For an UPDATE operation, calculate the difference and update the stock
  ELSIF TG_OP = 'UPDATE' THEN
    UPDATE users
    SET email = new.email,
    id_role = new.id_role
    WHERE email = old.email;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_user_on_update_karyawan() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: approval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approval (
    id_approval character varying NOT NULL,
    id_pengajuan character varying,
    id_karyawan character varying,
    status character varying,
    deskripsi character varying
);


ALTER TABLE public.approval OWNER TO postgres;

--
-- Name: approval_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.approval_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.approval_seq OWNER TO postgres;

--
-- Name: barang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.barang (
    id_barang character varying NOT NULL,
    nama_barang character varying,
    deskripsi character varying
);


ALTER TABLE public.barang OWNER TO postgres;

--
-- Name: barang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.barang_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.barang_seq OWNER TO postgres;

--
-- Name: global_param; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.global_param (
    id integer,
    name text,
    data_type text,
    value text
);


ALTER TABLE public.global_param OWNER TO postgres;

--
-- Name: karyawan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.karyawan (
    id_karyawan text,
    nama_karyawan text,
    alamat text,
    email text,
    id_role character varying
);


ALTER TABLE public.karyawan OWNER TO postgres;

--
-- Name: karyawan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.karyawan_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.karyawan_seq OWNER TO postgres;

--
-- Name: pengajuan_barang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pengajuan_barang (
    id_pengajuan character varying NOT NULL,
    nama_pengajuan character varying,
    id_barang character varying,
    id_karyawan character varying,
    kuantitas integer,
    kuantitas_approval integer,
    deskripsi character varying
);


ALTER TABLE public.pengajuan_barang OWNER TO postgres;

--
-- Name: pengajuan_barang_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pengajuan_barang_detail (
    id_pengajuan character varying(20),
    id_barang character varying(20),
    qty integer,
    approved_qty integer
);


ALTER TABLE public.pengajuan_barang_detail OWNER TO postgres;

--
-- Name: pengajuan_barang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pengajuan_barang_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pengajuan_barang_seq OWNER TO postgres;

--
-- Name: pengajuan_pettycash; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pengajuan_pettycash (
    id_pengajuan character varying NOT NULL,
    nama_pengajuan character varying,
    nominal integer,
    nominal_approval integer,
    id_karyawan character varying,
    deskripsi character varying
);


ALTER TABLE public.pengajuan_pettycash OWNER TO postgres;

--
-- Name: pertanggung_jawaban; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pertanggung_jawaban (
    id_pertanggung_jawab character varying NOT NULL,
    id_pengajuan character varying,
    nominal integer,
    deskripsi character varying
);


ALTER TABLE public.pertanggung_jawaban OWNER TO postgres;

--
-- Name: role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role (
    id_role integer NOT NULL,
    nama_role character varying,
    role_level integer,
    deskripsi character varying
);


ALTER TABLE public.role OWNER TO postgres;

--
-- Name: role_id_role_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_id_role_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_role_seq OWNER TO postgres;

--
-- Name: role_id_role_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_id_role_seq OWNED BY public.role.id_role;


--
-- Name: stok; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stok (
    id_stok integer NOT NULL,
    id_barang character varying,
    stok integer
);


ALTER TABLE public.stok OWNER TO postgres;

--
-- Name: stok_id_stok_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stok_id_stok_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stok_id_stok_seq OWNER TO postgres;

--
-- Name: stok_id_stok_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stok_id_stok_seq OWNED BY public.stok.id_stok;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying,
    password character varying,
    id_role character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: v_karyawan; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_karyawan AS
 SELECT k.id_karyawan,
    k.nama_karyawan,
    k.alamat,
    k.email,
    k.id_role,
    r.nama_role,
    r.role_level,
    r.deskripsi
   FROM (public.karyawan k
     JOIN public.role r ON (((k.id_role)::text = ((r.id_role)::character varying)::text)));


ALTER TABLE public.v_karyawan OWNER TO postgres;

--
-- Name: v_pengajuan_barang; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_pengajuan_barang AS
 SELECT pb.id_pengajuan,
    pb.nama_pengajuan,
    pb.id_barang,
    b.nama_barang,
    pb.id_karyawan,
    k.nama_karyawan,
    ''::text AS jabatan,
    pb.kuantitas,
    pb.kuantitas_approval,
    pb.deskripsi,
    COALESCE(a.status, 'OPEN'::character varying) AS status
   FROM (((public.pengajuan_barang pb
     LEFT JOIN public.karyawan k ON (((pb.id_karyawan)::text = k.id_karyawan)))
     JOIN public.barang b ON (((pb.id_barang)::text = (b.id_barang)::text)))
     LEFT JOIN public.approval a ON (((pb.id_pengajuan)::text = (a.id_pengajuan)::text)));


ALTER TABLE public.v_pengajuan_barang OWNER TO postgres;

--
-- Name: v_stock; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_stock AS
 SELECT s.id_stok,
    b.id_barang,
    b.nama_barang,
    b.deskripsi,
    COALESCE(s.stok, 0) AS stok
   FROM (public.stok s
     RIGHT JOIN public.barang b ON (((s.id_barang)::text = (b.id_barang)::text)));


ALTER TABLE public.v_stock OWNER TO postgres;

--
-- Name: v_users; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_users AS
 SELECT u.id,
    u.email,
    u.password,
    k.id_role,
    k.id_karyawan,
    k.nama_karyawan,
    k.alamat,
    r.nama_role,
    r.role_level,
    r.deskripsi
   FROM ((public.users u
     JOIN public.karyawan k ON (((u.email)::text = k.email)))
     JOIN public.role r ON ((((r.id_role)::character varying)::text = (k.id_role)::text)));


ALTER TABLE public.v_users OWNER TO postgres;

--
-- Name: role id_role; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role ALTER COLUMN id_role SET DEFAULT nextval('public.role_id_role_seq'::regclass);


--
-- Name: stok id_stok; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok ALTER COLUMN id_stok SET DEFAULT nextval('public.stok_id_stok_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: approval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approval (id_approval, id_pengajuan, id_karyawan, status, deskripsi) FROM stdin;
\.
COPY public.approval (id_approval, id_pengajuan, id_karyawan, status, deskripsi) FROM '$$PATH$$/2959.dat';

--
-- Data for Name: barang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.barang (id_barang, nama_barang, deskripsi) FROM stdin;
\.
COPY public.barang (id_barang, nama_barang, deskripsi) FROM '$$PATH$$/2953.dat';

--
-- Data for Name: global_param; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.global_param (id, name, data_type, value) FROM stdin;
\.
COPY public.global_param (id, name, data_type, value) FROM '$$PATH$$/2948.dat';

--
-- Data for Name: karyawan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.karyawan (id_karyawan, nama_karyawan, alamat, email, id_role) FROM stdin;
\.
COPY public.karyawan (id_karyawan, nama_karyawan, alamat, email, id_role) FROM '$$PATH$$/2949.dat';

--
-- Data for Name: pengajuan_barang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pengajuan_barang (id_pengajuan, nama_pengajuan, id_barang, id_karyawan, kuantitas, kuantitas_approval, deskripsi) FROM stdin;
\.
COPY public.pengajuan_barang (id_pengajuan, nama_pengajuan, id_barang, id_karyawan, kuantitas, kuantitas_approval, deskripsi) FROM '$$PATH$$/2954.dat';

--
-- Data for Name: pengajuan_barang_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pengajuan_barang_detail (id_pengajuan, id_barang, qty, approved_qty) FROM stdin;
\.
COPY public.pengajuan_barang_detail (id_pengajuan, id_barang, qty, approved_qty) FROM '$$PATH$$/2963.dat';

--
-- Data for Name: pengajuan_pettycash; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pengajuan_pettycash (id_pengajuan, nama_pengajuan, nominal, nominal_approval, id_karyawan, deskripsi) FROM stdin;
\.
COPY public.pengajuan_pettycash (id_pengajuan, nama_pengajuan, nominal, nominal_approval, id_karyawan, deskripsi) FROM '$$PATH$$/2961.dat';

--
-- Data for Name: pertanggung_jawaban; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pertanggung_jawaban (id_pertanggung_jawab, id_pengajuan, nominal, deskripsi) FROM stdin;
\.
COPY public.pertanggung_jawaban (id_pertanggung_jawab, id_pengajuan, nominal, deskripsi) FROM '$$PATH$$/2962.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role (id_role, nama_role, role_level, deskripsi) FROM stdin;
\.
COPY public.role (id_role, nama_role, role_level, deskripsi) FROM '$$PATH$$/2952.dat';

--
-- Data for Name: stok; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stok (id_stok, id_barang, stok) FROM stdin;
\.
COPY public.stok (id_stok, id_barang, stok) FROM '$$PATH$$/2957.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, id_role) FROM stdin;
\.
COPY public.users (id, email, password, id_role) FROM '$$PATH$$/2947.dat';

--
-- Name: approval_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.approval_seq', 4, true);


--
-- Name: barang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.barang_seq', 2, true);


--
-- Name: karyawan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.karyawan_seq', 15, true);


--
-- Name: pengajuan_barang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pengajuan_barang_seq', 2, true);


--
-- Name: role_id_role_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_id_role_seq', 5, true);


--
-- Name: stok_id_stok_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stok_id_stok_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 21, true);


--
-- Name: approval approval_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval
    ADD CONSTRAINT approval_pkey PRIMARY KEY (id_approval);


--
-- Name: barang barang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.barang
    ADD CONSTRAINT barang_pkey PRIMARY KEY (id_barang);


--
-- Name: pengajuan_barang pengajuan_barang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pengajuan_barang
    ADD CONSTRAINT pengajuan_barang_pkey PRIMARY KEY (id_pengajuan);


--
-- Name: pengajuan_pettycash pengajuan_pettycash_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pengajuan_pettycash
    ADD CONSTRAINT pengajuan_pettycash_pkey PRIMARY KEY (id_pengajuan);


--
-- Name: pertanggung_jawaban pertanggung_jawaban_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pertanggung_jawaban
    ADD CONSTRAINT pertanggung_jawaban_pkey PRIMARY KEY (id_pertanggung_jawab);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id_role);


--
-- Name: stok stok_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok
    ADD CONSTRAINT stok_pkey PRIMARY KEY (id_stok);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: karyawan trg_approval_update_stock_qty; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_approval_update_stock_qty AFTER DELETE OR UPDATE ON public.karyawan FOR EACH ROW EXECUTE PROCEDURE public.update_user_on_update_karyawan();


--
-- Name: users trg_insert_id_role; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_insert_id_role AFTER INSERT ON public.users FOR EACH ROW EXECUTE PROCEDURE public.insert_id_role();


--
-- Name: approval trg_update_stock_on_approval; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_update_stock_on_approval AFTER INSERT OR UPDATE ON public.approval FOR EACH ROW EXECUTE PROCEDURE public.f_update_stock_barang();


--
-- PostgreSQL database dump complete
--

